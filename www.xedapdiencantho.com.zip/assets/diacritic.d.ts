declare module "diacritic";
