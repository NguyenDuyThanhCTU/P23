import React from "react";

const Footer = () => {
  return (
    <div>
      <div>Footer</div>
    </div>
  );
};

export default Footer;
