import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyCwQOr7tXB7PlH9RJV6Mj8e9rCpRjO89Go",

  authDomain: "quangcaocokhixaydung.firebaseapp.com",

  projectId: "quangcaocokhixaydung",

  storageBucket: "quangcaocokhixaydung.appspot.com",

  messagingSenderId: "226633407681",

  appId: "1:226633407681:web:f3c5897597e5e451680840",

  measurementId: "G-YSWX6P3JHT",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
// export const db = getFirestore(app);

export const auth = getAuth(app);
